from django.contrib import admin
from .models import Hero, Villain

admin.site.register(Hero)
admin.site.register(Villain)